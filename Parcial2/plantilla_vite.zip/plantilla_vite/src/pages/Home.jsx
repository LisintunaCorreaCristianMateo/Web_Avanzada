const Home=()=><h1>Bienbenidos a la pagina de inicio</h1>;
export default Home;