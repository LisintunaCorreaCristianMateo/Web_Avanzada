// import {useNavigate} from 'react-router-dom';
import {useState} from 'react';
const Login=()=>{
    // const navigate=useNavigate();
    const [email,setEmail]=useState('');
    

    const handleLogin = ()=> {
        if(email.trim() ===''){
            alert ('Por favor ingrese un email valido');
            return;
        }
    }

return(
    <div>
    <h1>Login</h1>
    <input 
    type="text" 
    placeholder='email'
    value={email}
    onChange={(e)=>setEmail(e.target.value)}
    />
    <button
        type="button"
        className="btn btn-outline-primary"
        onClick={handleLogin}
    >
        Ingresar
    </button>
    

    </div>

);

};
export default Login;